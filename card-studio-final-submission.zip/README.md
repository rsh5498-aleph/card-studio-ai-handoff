# 대화가 끊겨도 이어지는 짤·카드 스튜디오

과제 3의 짤·카드 스튜디오를 AI A(Codex)와 AI B(ChatGPT)가 저장소와 인수인계 문서만으로 이어서 개선한 과제 5 결과물입니다.

## 개선 기능

- 카드 편집 실행 취소·다시 실행
- 최대 50개의 편집 이력
- 브라우저 자동 임시저장 및 안전한 복구
- 이미지 원본 데이터를 제외한 기기 내 저장
- 고정된 자동 검사 10개

자세한 실험 과정과 비교 결과는 [REPORT.md](REPORT.md)를 확인하세요.

## 실행

```bash
pnpm install --frozen-lockfile
pnpm test:acceptance
pnpm build
pnpm dev
```
