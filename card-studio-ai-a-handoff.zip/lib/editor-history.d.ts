export type EditorHistory<T> = { past: T[]; present: T; future: T[] };
export function createHistory<T>(initial: T): EditorHistory<T>;
export function commitHistory<T>(history: EditorHistory<T>, next: T): EditorHistory<T>;
export function undoHistory<T>(history: EditorHistory<T>): EditorHistory<T>;
export function redoHistory<T>(history: EditorHistory<T>): EditorHistory<T>;
export function serializeDraft<T extends object>(card: T): string;
export function restoreDraft<T = unknown>(raw: string): T | null;
