import test from 'node:test';
import assert from 'node:assert/strict';
import {
  commitHistory,
  createHistory,
  redoHistory,
  restoreDraft,
  serializeDraft,
  undoHistory,
} from '../lib/editor-history.mjs';

const card = (text = '처음', extra = {}) => ({
  id: 'card-1', name: '검사 카드', text, ratio: '1:1', fontSize: 54,
  color: '#ffffff', x: 50, y: 68, imageScale: 100, imageX: 50,
  imageY: 50, rights: { creator: '직접 제작', source: '', license: '본인 제작' },
  updatedAt: '2026-09-04T00:00:00.000Z', ...extra,
});

test('T05-01 최초 이력은 현재 상태만 보존한다', () => {
  assert.deepEqual(createHistory(card()), { past: [], present: card(), future: [] });
});

test('T05-02 새 편집은 이전 상태를 과거에 기록한다', () => {
  const next = commitHistory(createHistory(card()), card('둘째'));
  assert.equal(next.past.at(-1).text, '처음');
  assert.equal(next.present.text, '둘째');
});

test('T05-03 실행 취소는 직전 상태로 이동한다', () => {
  const edited = commitHistory(createHistory(card()), card('둘째'));
  assert.equal(undoHistory(edited).present.text, '처음');
});

test('T05-04 다시 실행은 취소한 상태를 복원한다', () => {
  const edited = commitHistory(createHistory(card()), card('둘째'));
  assert.equal(redoHistory(undoHistory(edited)).present.text, '둘째');
});

test('T05-05 취소 후 새 편집은 미래 이력을 제거한다', () => {
  const edited = commitHistory(createHistory(card()), card('둘째'));
  const branched = commitHistory(undoHistory(edited), card('새 갈래'));
  assert.deepEqual(branched.future, []);
});

test('T05-06 동일 상태는 중복 기록하지 않는다', () => {
  const initial = createHistory(card());
  assert.deepEqual(commitHistory(initial, card()), initial);
});

test('T05-07 과거 이력은 최근 50개만 유지한다', () => {
  let history = createHistory(card('0'));
  for (let i = 1; i <= 60; i += 1) history = commitHistory(history, card(String(i)));
  assert.equal(history.past.length, 50);
  assert.equal(history.past[0].text, '10');
});

test('T05-08 임시저장은 이미지 원본을 빼고 이름을 유지한다', () => {
  const saved = JSON.parse(serializeDraft(card('사진', { image: 'data:image/png;base64,AAA', imageName: 'sample.png' })));
  assert.equal(saved.image, undefined);
  assert.equal(saved.imageName, 'sample.png');
});

test('T05-09 올바른 임시저장 JSON을 복구한다', () => {
  assert.deepEqual(restoreDraft(JSON.stringify(card('복구'))), card('복구'));
});

test('T05-10 손상되거나 불완전한 임시저장은 무시한다', () => {
  assert.equal(restoreDraft('{broken'), null);
  assert.equal(restoreDraft(JSON.stringify({ text: '누락' })), null);
});
